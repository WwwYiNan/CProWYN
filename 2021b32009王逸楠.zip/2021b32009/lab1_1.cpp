#include "SequList.h"
int main()
{
    SqList L;
    ElemType a[] = {3,3,4,4,5,6,7,8,9};
    CreateList(L,a,9);
    DispList(L);
    AAA(L);
    DispList(L);
}
